package DB;

public class Constants {
	public static int COURSES = 0;
	public static int DEPARTMENT = 1;
	public static int ENROLLMENT = 2;
	public static int PROF = 3;
	public static int STUDENT = 4;
	public static int BOOK = 5;
}
