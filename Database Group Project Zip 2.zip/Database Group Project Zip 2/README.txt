Instructions:
	1. Run the StudentRecordComplete.sql to create the database, populate the database and grant privileges for connectivity to the app.
	2. Open AppDemo.jar to run the app.
	3. To view the main (add/drop/edit) functionality of the app click “Tables/Edit”
		-Please note, you may not edit Enrolment entries
	4. To view our bonus procedure, return to the menu with the —> button, then click “View Courses”
	5. To view our bonus view, return to the menu with the —> button, then click “View Student Fees”




Software/Tools:
	1. MySQLWorkbench 6.3.10.CE
	2. Eclipse 4.7 for Mac OS X
	3. javax.swing or Java Swing (Java SE 7)